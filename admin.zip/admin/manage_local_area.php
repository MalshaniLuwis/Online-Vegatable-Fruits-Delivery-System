<?php
require('top.inc.php');
$districts='';
$msg='';
$local_area='';
if(isset($_GET['id']) && $_GET['id']!=''){
	$id=get_safe_value($con,$_GET['id']);
	$res=mysqli_query($con,"select * from local_area where id='$id'");
	$check=mysqli_num_rows($res);
	if($check>0){
		$row=mysqli_fetch_assoc($res);
		$local_area=$row['local_area'];
		$districts=$row['district_id'];
	}else{
		header('location:local_area.php');
		die();
	}
}

if(isset($_POST['submit'])){
	$districts=get_safe_value($con,$_POST['district_id']);
	$local_area=get_safe_value($con,$_POST['local_area']);
	$res=mysqli_query($con,"select * from local_area where district_id='$districts' and local_area='$local_area'");
	$check=mysqli_num_rows($res);
	if($check>0){
		if(isset($_GET['id']) && $_GET['id']!=''){
			$getData=mysqli_fetch_assoc($res);
			if($id==$getData['id']){
			
			}else{
				$msg="Local Area already exist";
			}
		}else{
			$msg="Local Area already exist";
		}
	}
	
	if($msg==''){
		if(isset($_GET['id']) && $_GET['id']!=''){
			mysqli_query($con,"update local_area set district_id='$districts',local_area='$local_area' where id='$id'");
		}else{
			
			mysqli_query($con,"insert into local_area(district_id,local_area) values('$districts','$local_area')");
		}
		header('location:local_area.php');
		die();
	}
}
?>
<div class="content pb-0">
            <div class="animated fadeIn">
               <div class="row">
                  <div class="col-lg-12">
                     <div class="card">
                        <div class="card-header"><strong>Local Area</strong><small> Form</small></div>
                        <form method="post">
							<div class="card-body card-block">
							   <div class="form-group">
									<label for="categories" class=" form-control-label">Districts</label>
									<select name="district_id" required class="form-control">
										<option value="">Select District</option>
										<?php
										$res=mysqli_query($con,"select * from districts");
										while($row=mysqli_fetch_assoc($res)){
											if($row['id']==$districts){
												echo "<option value=".$row['id']." selected>".$row['districts']."</option>";
											}else{
												echo "<option value=".$row['id'].">".$row['districts']."</option>";
											}
										}
										?>
									</select>
								</div>
								<div class="form-group">
									<label for="categories" class=" form-control-label">local area</label>
									<input type="text" name="local_area" placeholder="Enter sub categories" class="form-control" required value="<?php echo $local_area?>">
								</div>
							   <button id="payment-button" name="submit" type="submit" class="btn btn-lg btn-info btn-block">
							   <span id="payment-button-amount">Submit</span>
							   </button>
							   <div class="field_error"><?php echo $msg?></div>
							</div>
						</form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         
<?php
require('footer.inc.php');
?>